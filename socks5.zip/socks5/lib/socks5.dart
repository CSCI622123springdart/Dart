import 'dart:convert';
import 'dart:io';
import 'dart:async';
import 'dart:typed_data';

class Socks5Helper {
  RawSocket clientSocket;
  RawSocket targetSocket;

  // Whether complete handcheck
  bool handshakeCompleted = false;
  // Whether complete connection
  bool connCompleted = false;

  Socks5Helper(this.clientSocket) {
    // Listening to socks client
    clientSocket.listen(
        (event) async {
          if (event == RawSocketEvent.read) {
            if (!handshakeCompleted) {
              // None handcheck
              handshakeCompleted = handshake();
            } else if (!connCompleted) {
              // None connection
              connCompleted = await createConnection();
            } else {
              if (targetSocket != null) {
                // forward clientsocket data
                forward(clientSocket, targetSocket);
              }
            }
          }
        },
        onError: (e) => print("Socks5Helper onError:$e"),
        onDone: () {
          // return Error
          clientSocket?.close();
          targetSocket?.close();
        });
  }

  //1. socks5 handcheck
  bool handshake() {
    // read bytedata from clientSocket
    Uint8List bytes = clientSocket.read(clientSocket.available());
    ByteData bd = ByteData.sublistView(bytes);
    var req = HandShakeRequest.from(bd);

    if (req.verify()) {
      clientSocket.write(HandShakeResponse.from(0x00).toByte());
      return true;
    }
    return false;
  }

  //2. create connection
  Future<bool> createConnection() async {
    // read bytedata from clientSocket
    Uint8List bytes = clientSocket.read(clientSocket.available());
    ByteData bd = ByteData.sublistView(bytes);

    var req = Socks5Request.from(bd);
    if (req.cmd != 0x01) {
      print("only support CONNECT CMD=${req.cmd}");
      var res = Socks5Response.from(
          0x07, IPv4(InternetAddress.tryParse('127.0.0.1').rawAddress, 8082));
      clientSocket.write(res.toByte());
      clientSocket.close();
      return false;
    }

    try {
      // get target server IP address
      var addr = await req.getAddress();
      // access target server and build socks5 connection
      targetSocket = await RawSocket.connect(addr, req.dst.port,
          timeout: Duration(seconds: 15));

      print('${addr.host} => ${addr.address}');

      var res = Socks5Response.from(
          0x00, IPv4(targetSocket.address.rawAddress, targetSocket.port));

      clientSocket.write(res.toByte());

      // Set the target server to listen.
      targetSocket.listen(
          (event) {
            if (event == RawSocketEvent.read) {
              forward(targetSocket, clientSocket);
            }
          },
          onError: (e) => print("target socket error:$e"),
          onDone: () {
            clientSocket.close();
            targetSocket.close();
          });
      return true;
    } catch (e) {
      var res = Socks5Response.from(
          0x06, IPv4(InternetAddress.tryParse("127.0.0.1").rawAddress, 8082));
      clientSocket.write(res.toByte());
      clientSocket.close();

      var errorMsg = (await req.getAddress()).host + " => $e";
      print(errorMsg);
    }
    return false;
  }

  //3. forward request
  void forward(RawSocket input, RawSocket output) {
    var bytes = input.read(input.available());
    output.write(bytes);
  }
}

/// HandShakeRequest
class HandShakeRequest {
  int ver;
  int nmethods;
  Uint8List methods;

  HandShakeRequest.from(ByteData blob) {
    ver = blob.getUint8(0);
    nmethods = blob.getUint8(1);
    if (nmethods > 0) {
      methods = blob.buffer.asUint8List(2, nmethods);
    }
  }

  // Verify
  bool verify() {
    if (ver != 0x05) {
      print("version is not supported");
      return false;
    }

    for (var it in methods) {
      if (it == 0x00) {
        return true;
      }
    }

    print("verification method is not supported");
    return false;
  }
}

/// HandShakeResponse
class HandShakeResponse {
  int ver = 0x05;
  int method;

  HandShakeResponse.from(this.method);

  Uint8List toByte() {
    ByteData bd = ByteData(2);
    bd.setUint8(0, ver);
    bd.setUint8(1, method);
    return bd.buffer.asUint8List();
  }
}

/// Socks5Request
class Socks5Request {
  int ver;
  int cmd;
  int rsv;
  int atyp;

  Dst dst;

  Socks5Request.from(ByteData blob) {
    ver = blob.getUint8(0);
    cmd = blob.getUint8(1);
    rsv = blob.getUint8(2);
    atyp = blob.getUint8(3);

    switch (atyp) {
      case 0x01: // IPv4 Address
        dst = IPv4(blob.buffer.asUint8List(4, 4), blob.getUint16(8));
        break;
      case 0x03: // Domain address
        var len = blob.getUint8(4);
        var hostBytes = blob.buffer.asUint8List(5, len);
        dst = Domain(ascii.decode(hostBytes), blob.getUint16(len + 5));
        break;
      case 0x04:
        break;
    }
  }

  Future<InternetAddress> getAddress() async {
    switch (atyp) {
      case 0x01:
        return (dst as IPv4).address;
      case 0x03:
        List<InternetAddress> addressList =
            await InternetAddress.lookup((dst as Domain).host);
        return addressList.first;
      default:
        return null;
    }
  }
}

class Dst {
  int port;
}

class IPv4 implements Dst, Bnd {
  int port;
  InternetAddress address;

  IPv4(Uint8List addr, this.port) {
    address =
        InternetAddress.fromRawAddress(addr, type: InternetAddressType.IPv4);
  }
}

class IPv6 implements Dst, Bnd {
  int port;
}

class Domain implements Dst, Bnd {
  int port;
  String host;

  Domain(this.host, this.port);
}

class Bnd {
  int port;
}

/// Socks5Response
class Socks5Response {
  int ver = 0x05;
  int rep;
  int rsv = 0x00;
  int atyp = 0x01;

  Bnd bnd;

  Socks5Response.from(this.rep, this.bnd);

  Uint8List toByte() {
    var bd = ByteData(10);
    bd.setUint8(0, ver);
    bd.setUint8(1, rep);
    bd.setUint8(2, rsv);
    bd.setUint8(3, atyp);

    Uint8List rawAddr = (bnd as IPv4).address.rawAddress;
    for (var i = 0; i < 4; i++) {
      bd.setUint8(4 + i, rawAddr[i]);
    }
    bd.setUint16(8, bnd.port);

    return bd.buffer.asUint8List();
  }
}
